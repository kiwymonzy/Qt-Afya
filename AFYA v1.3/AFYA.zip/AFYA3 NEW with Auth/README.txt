DATABASE TABLES
    Account
    AccountActivity
    AccountStatus
    AccountType
    BooleanValue
    Login
    LoginActivity
    NamePrefix

*** ADMIN
    -Can Register New User
    -Can see number of Employee per User Accounts
    -can see the USER SUBMITTED FEEDBACK REPORTS
    -Edit his/her own Profile (Email,Password)

***USERS
    -Edit his/her Profile (Email,Password)
    -can submit the USER FEEDBACK REPORTS


*** USER
    @RECEIPTION & BILLING
        -Can edit Patient TAB
        -Can edit Outsiders TAB
        -Can See Report TAB
        -Can See Billing TAB


