#ifndef HEADERS_H
#define HEADERS_H
#include "databaseconnection.h"
//#include"libraries/qrcode/QrCode.hpp"


#endif // HEADERS_H
#include<QMainWindow>
#include<QComboBox>
#include<QString>
#include<QLineEdit>
#include<QTableView>
#include<QTimer>
#include<QDateTime>
#include<QSqlQueryModel>
#include<QDebug>
#include<QFileInfo>
#include<QtSql>
#include<QSqlDatabase>
#include<QSqlDriver>
#include<QFileInfo>
#include<iostream>
#include<QMessageBox>
#include <QDialog>
#include <QtGui>
#include <QtCore>
#include <QPainter>
#include <QPixmap>
#include <QPainterPath>
#include <QTableWidget>
#include <QComboBox>
#include <QLabel>
#include <QFileDialog>
#include <QDialogButtonBox>
#include <QLineEdit>
#include <QDialog>


